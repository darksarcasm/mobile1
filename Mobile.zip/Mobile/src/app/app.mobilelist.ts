import { Component, OnInit } from '@angular/core';
import { IMobile } from './mobile';
import { MobileService } from './mobile.service';

@Component({
    selector: '<my-component></my-component>',
    templateUrl: './app.mobilecomponent.html',
    providers: [MobileService]
})

export class MobileList implements OnInit {
    mobiles: IMobile[];
    column:any;

    constructor(private mobileService: MobileService) {
    
    }
    sortBymobId():void {
        this.mobileService.onclickId(this.mobiles);
    }
    sortBymobName() {
        this.mobileService.onclickName(this.mobiles);
    }
    sortBymobPrice():void {
        this.mobileService.onclickPrice(this.mobiles); 
    }
    
    delete(mob:any){
        this.mobileService.ondelete(mob,this.mobiles);
    }

    ngOnInit(): void {
        console.log("ng-init called...");
        this.mobileService.getAllMobiles().subscribe((mobData) => this.mobiles = mobData);
    }  
}