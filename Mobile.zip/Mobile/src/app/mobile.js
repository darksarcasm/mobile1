"use strict";
var IMobile = (function () {
    function IMobile(mobId, mobName, mobPrice) {
        this.mobId = mobId;
        this.mobName = mobName;
        this.mobPrice = mobPrice;
    }
    return IMobile;
}());
exports.IMobile = IMobile;
