import { Injectable } from '@angular/core';
import { IMobile } from './mobile';
import {Http,Response} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import "rxjs/add/operator/map"

@Injectable()
export class MobileService {
    
    mobiles: IMobile[];
    ind:number;
    constructor(private http: Http) {
        
    }
    getAllMobiles():Observable< IMobile[]> {
            return this.http.get("app/mobile.json").map((response: Response) => <IMobile[]>response.json());
    }
    
    onclickId(mobiles:IMobile[]) {
        mobiles.sort(function(mob1, mob2) {
           return mob1.mobId - mob2.mobId;
        });  
    }
    onclickName(mobiles:IMobile[]) {
        console.log("Sorting by Name...");
        mobiles.sort(function(mob1, mob2) {
            return (mob1.mobName.localeCompare(mob2.mobName));
        });
    }
    onclickPrice(mobiles:IMobile[]) {
        mobiles.sort(function(mob1, mob2) {
           return mob1.mobPrice - mob2.mobPrice;
        });  
    }
    ondelete(mob:any,mobiles:IMobile[]){
        this.ind=mobiles.indexOf(mob,0);
        console.log(this.ind);
        mobiles.splice(this.ind, 1);
     }
}
